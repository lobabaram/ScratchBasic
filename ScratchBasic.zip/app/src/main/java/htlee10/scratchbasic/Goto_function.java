package htlee10.scratchbasic;

import java.util.HashMap;

/**
 * Created by Hun Tae Lee on 10/05/2016.
 */
public class Goto_function {
    public static int Goto_statement(String[] temp, HashMap<String, String> dict_variable){
        //Has format of {GOTO, value}
        int goto_lineNo;
        String str_goto_lineNo;

        try{ //if value can be changed to integer, use it
            goto_lineNo = Integer.parseInt(temp[1]);
        }
        catch (NumberFormatException e){ //if value is not an integer, find it from dict_variable.
            str_goto_lineNo = dict_variable.get(temp[1]);
            goto_lineNo = Integer.parseInt(str_goto_lineNo);
        }
        return goto_lineNo;
    }
}
